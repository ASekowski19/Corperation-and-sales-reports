package Chap3;

public class DetailedSalesReport extends SalesReport {

	public DetailedSalesReport(String FAANG, double[] salesChart) {
		super(FAANG, salesChart);
	}
	
	public String getHeader() {
		return "Detailed Sales Report for " + getFAANG();
	}

	public String getBody() {
		int lines = salesChart.length/5;
		int lastLine = salesChart.length%5;
		StringBuilder body = new StringBuilder();
		body.append(String.format("The average sales for company is $%,.2f\n\n", averageSales()));
		body.append("All sales: \n");
		int i = 0;
		for (int a = 0; a < lines; a++) {
			for (int b = 0; b<5; b++) {
			body.append(String.format("$%,.2f ", salesChart[i++]));
			}
		body.append("\n");
	}
	for (int a = 0; a<lastLine; a++) {
		body.append(String.format("$%,.2f ", salesChart[i++]));
	}
	return body.toString();
	}
}
