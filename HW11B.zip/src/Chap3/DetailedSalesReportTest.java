package Chap3;

public class DetailedSalesReportTest {

	public static void main(String[] args) {
		testDetailedHeaderAmazon();
		testDetailedBodyAmazon();
		testDetailedHeaderNetflix();
		testDetailedBodyNetFlix();
		testDetailedHeaderFacebook();
		testDetailedBodyFacebook();
		testDetailedHeaderGoogle();
		testDetailedBodyGoogle();
		testDetailedHeaderApple();
		testDetailedBodyApple();
		
	}
	private static void testDetailedHeaderAmazon() {
		DetailedSalesReport a = buildDSR1();
		System.out.println("Detailed Sales Report for " + a.getHeader());
		System.out.println("");
	}
	private static void testDetailedBodyAmazon() {
		DetailedSalesReport a = buildDSR1();
		System.out.println("The average sales is " + a.getBody());
		System.out.println("");
	}
	
	private static void testDetailedHeaderNetflix() {
		DetailedSalesReport b = buildDSR2();
		System.out.println("Detailed Sales Report for " + b.getHeader());
		System.out.println("");
	}
	
	private static void testDetailedBodyNetFlix() {
		DetailedSalesReport b = buildDSR2();
		System.out.println("The average sales is " + b.getBody());
		System.out.println("");
	}
	
	private static void testDetailedHeaderFacebook() {
		DetailedSalesReport c = buildDSR3();
		System.out.println("Detailed Sales Report for " + c.getHeader());
		System.out.println("");
	}
	
	private static void testDetailedBodyFacebook() {
		DetailedSalesReport c = buildDSR3();
		System.out.println("The average sales is " + c.getBody());
		System.out.println("");
	}
	
	private static void testDetailedHeaderGoogle() {
		DetailedSalesReport d = buildDSR4();
		System.out.println("Detailed Sales Report for " + d.getHeader());
		System.out.println("");
	}
	
	private static void testDetailedBodyGoogle() {
		DetailedSalesReport d = buildDSR4();
		System.out.println("The average sales is " + d.getBody());
		System.out.println("");
	}
	private static void testDetailedHeaderApple() {
		DetailedSalesReport e = buildDSR5();
		System.out.println("Detailed Sales Report for " + e.getHeader());
		System.out.println("");
	}
	
	private static void testDetailedBodyApple() {
		DetailedSalesReport e = buildDSR5();
		System.out.println("The average sales is " + e.getBody());
		System.out.println("");
	}
	
	static double[] salesChart1 = {33423.32434, 93223.92, 78293.2342, 23449.9032, 33923.92038, 49882.23432, 55239.9032, 90202.2393, 77234.9923, 63292.23423, 82332.23423, 46232.32432};
	static double[] salesChart2 = {45452.12345, 57639.69, 34562.6749, 78483.8612, 78402.95086, 58994.33323, 89898.0297, 89838.8993, 83838.4545, 84738.38383, 73939.83737, 83839.12121};
	static double[] salesChart3 = {84848.39393, 93939.09, 93939.2928, 69232.0823, 39202.06955, 48404.39494, 49483.9839, 13903.3333, 87833.8373, 83983.87338, 87333.87333, 98399.87338};
	static double[] salesChart4 = {84848.39393, 93939.09, 93939.2928, 69232.0823, 39202.06955};
	static double[] salesChart5 = {84848.39393, 93939.09, 69232.0823, 39202.06955};
	
	private static DetailedSalesReport buildDSR1() {
		DetailedSalesReport a;
		a  = new DetailedSalesReport("Amazon", salesChart1);
		return a;
	}
	private static DetailedSalesReport buildDSR2() {
		DetailedSalesReport b;
		b = new DetailedSalesReport("Netflix", salesChart2);
		return b;
	}
	private static DetailedSalesReport buildDSR3() {
		DetailedSalesReport c;
		c  = new DetailedSalesReport("Facebook", salesChart3);
		return c;
	}
	private static DetailedSalesReport buildDSR4() {
		DetailedSalesReport d;
		d  = new DetailedSalesReport("Google", salesChart4);
		return d;
	}
	private static DetailedSalesReport buildDSR5() {
		DetailedSalesReport e;
		e  = new DetailedSalesReport("Apple", salesChart5);
		return e;
	}
}
