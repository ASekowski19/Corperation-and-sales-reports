package Chap3;

public class SalesReport {
	protected String FAANG;
	protected double[] salesChart;
	
	public SalesReport(String FAANG, double[] salesChart) {
		this.FAANG = FAANG;
		this.salesChart = salesChart;
	}
	
	public String getFAANG() {
		return FAANG;
	}
	
	public String getHeader() {
		return "Aggregate sales report for " + FAANG;
	}
	
	protected String getBody() {
		String Body = String.format("The average sales is $%,.2f", averageSales());
		return Body;
	}
	
	public double averageSales() {
		double avg = 0.0;
		for(double sales : salesChart) 
			avg += sales;
		avg /= salesChart.length;
		return avg;
	}
	
	public String getReport() {
		String report = getHeader() + " " +getBody();
		return report;
	}
}
