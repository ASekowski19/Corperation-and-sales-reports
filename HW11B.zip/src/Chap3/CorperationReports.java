package Chap3;


public class CorperationReports {
	private SalesReport[] reports = new SalesReport[10];
	private int numReports = 0;
	
	public CorperationReports() {
	}
	
	public int getNumReports() {
		return numReports;
	}
	
	public void addReport(SalesReport rpt) {
		if (numReports < reports.length) {
			reports[numReports++] = rpt;
		}
	}
	public SalesReport getReport(int i) {
		if (i>=0 && i<numReports) {
			return reports[i];
		}
		return null;
	}
	
	public SalesReport removeReport(int i) {
		if (i >= 0 && i < numReports) {
			SalesReport removedReports = reports[i];
			for (int a=i+1; a < numReports; a++) {
				reports[a-1] = reports[a];
			}
			numReports--;
			return removedReports;
		}
		return null;
	}
	public String toString() {
		StringBuilder msg = new StringBuilder("");
		for(int i = 0; i < numReports; i++) {
			if(reports[i] instanceof DetailedSalesReport) {
				//Works only for DetailedSalesReport
				msg.append("\nDaitledSalesReport ==> \n");
			}
			else {
				msg.append("\nSalesReport ==> \n");
			}
			String report = reports[i].getHeader() + "\n" + reports[i].getBody();
			msg.append(report + "\n");
		}
		return msg.toString();
	}
	
	public DetailedSalesReport getReportLargestAverageSalesDetailed() {
		DetailedSalesReport DetailedLargestAvg = null;
		
		double largest = 0.0;
		for (int i = 0; i < numReports; i++) {
			SalesReport sr = reports[i];
			if (sr instanceof DetailedSalesReport) {
				if(sr.averageSales() > largest) {
					largest = sr.averageSales();
					DetailedLargestAvg = (DetailedSalesReport)sr;
				}
			}
		}
		return DetailedLargestAvg;
	}
	
	public double getLargestAverageSalesDetailed() {
		double largest = 0.0;
		for (int i = 0; i < numReports; i++) {
			SalesReport sr = reports[i];
			if (sr instanceof DetailedSalesReport) {
				if (sr.averageSales() > largest) {
					largest = sr.averageSales();
				}
			}
		}
		return largest;
	}
	
	public DetailedSalesReport[] getDetailedReports() {
		DetailedSalesReport[] detailedReports = new DetailedSalesReport[getNumDetailedReports()];
		int a = 0;
		for (int i= 0; i < numReports; i++) {
			SalesReport sr = reports[i];
			if (sr instanceof DetailedSalesReport) {
				detailedReports[a++] = (DetailedSalesReport)sr;
			}
		}
		return detailedReports;
	}
	
	private int getNumDetailedReports() {
		int num = 0;
		for (int i = 0; i < numReports; i++) {
			if ( reports[i] instanceof DetailedSalesReport) {
				num++;
			}
		}
		return num;
	
	}
}
