package Chap7;
import java.util.ArrayList;
import java.util.List;

public class Person {
	private String name;
	private List<Account> accounts = new ArrayList<>();
	
	public Person(String name) {
		this.name = name;
	}
	
	public String getname() {
		return name;
	}
	
	public int getNumAccounts() {
		return accounts.size();
	}
	public void addAccount(Account a) {
		accounts.add(a);
	}
	
	public Account getAccount(int i) {
		if((i >= 0) && (i < accounts.size())) {
			return accounts.get(i);
		}
		return null;
	}

	
	public double getTotalBalance() {
		double sum = 0.0;
		for(Account a : accounts) {
			sum += a.getBalance();
		}
		return sum;
	}
	
	@Override
	public String toString() {
		String msg = String.format("name: %s, tot bal=$%,.2f, num accounts= %d\n", name, getTotalBalance(), getNumAccounts());
		for (int i = 0; i < getNumAccounts(); i++) {
			String acnt  = String.format("%d - %s\n", i+1, accounts.get(i));
			msg += acnt;
		}
		return msg;
	}
	
}
