package Chap7;

import java.io.File;
import java.util.List;

public class personIOTest {
	static File[] files = {
			new File("src/Chap7/people1.txt"),
			new File("src/Chap7/people2.txt"),
			new File("src/Chap7/people3.txt"),
			new File("src/Chap7/people4.txt")
	};

	public static void main(String[] args) {
		testReadPeople(1);
		testReadPeople(2);
		testReadPeople(3);

	}
	private static void testReadPeople(int ver) {
		for(File file : files) {
			testReadPeople(file, ver);
		}
	}
	private static void testReadPeople(File file, int ver) {
		String msg = String.format("\ntestReadPeople%d(), file: %s\n", ver, file.getName());
		System.out.println(msg);
		List<Person> people = null;
		switch(ver) {
		case 1: people = PersonIO.readPeople(file);
		break;
		case 2: people = PersonIO.readPeople2(file);
		break;
		case 3: people = PersonIO.readPeople3(file);
		}
		for(Person p : people) {
			System.out.println(p);
		}
	}

}
