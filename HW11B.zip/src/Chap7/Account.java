package Chap7;

public abstract class Account {
	protected double balance;
	
	public Account (double balance) {
		this.balance = balance;
	}
	
	public double getBalance() {
		return balance;
	}
	public void deposit(double amount) {
		balance += amount;
	}
	public void withdraw(double amount) {
		balance -= amount;
	}
	
	public abstract void endOfMonth();
	
	@Override 
	public String toString () {
		return String.format("balance =$%,.2f",balance);
	}
}
