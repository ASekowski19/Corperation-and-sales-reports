package Chap7;

public class BasicAccount extends Account{
	public BasicAccount(double balance) {
		super (balance);
	}

	@Override
	public void endOfMonth() {
		balance -= 5.0;
		if(balance < 0.0) {
			balance -= 25.0;
		}
	}
	
	@Override 
	public String toString() {
		return String.format("Basic: %s", super.toString());
	}
}
