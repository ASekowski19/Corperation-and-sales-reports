package Chap7;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PersonIO {
	
	public static void main1(String[] args) {
		File inFile = new File("src/Chap7/people1.txt");
		List<Person> people = readPeople3(inFile);
		
		for(Person p : people) {
			System.out.println(p);
		}
	}

	public static void main(String[] args) {
	}
	public static List<Person> readPeople (File file) {
		ArrayList<Person> people = new ArrayList<>();
		
		try {
			Scanner input = new Scanner(file);
			String name = input.nextLine();
			Account a;
			while(input.hasNext()) {
				Person p = new Person(name);
				boolean hasMoreAccounts = true;
				while(hasMoreAccounts) {
					String line = input.nextLine();
					String[] tokens = line.split("\\s");
					if(tokens.length == 1) {
						people.add(p);
						name = tokens[0];
						hasMoreAccounts = false;
						continue;
					}
					else if(tokens.length == 2) {
						double bal = Double.parseDouble(tokens[1]);
						a = new BasicAccount(bal);
					}
					else {
						double bal = Double.parseDouble(tokens[1]);
						double intRate = Double.parseDouble(tokens[2]);
						a = new GoldAccount(bal, intRate);
					}
					p.addAccount(a);
					if(!input.hasNext()) {
						hasMoreAccounts = false;
						people.add(p);
					}
				}
			}
			input.close();
		}
		catch(IOException e) {
			System.out.println(e);
		}
		return people;

	}
	
	public static List<Person> readPeople2(File file) {
		ArrayList<Person> people = new ArrayList<>();
		
		try {
			Scanner input = new Scanner(file);
			String name = input.nextLine();
			Person p = new Person(name);
			Account a;
			while(input.hasNext()) {
				String[] tokens = input.nextLine().split("\\s+");
				if(tokens.length == 1) {
					people.add(p);
					p = new Person(tokens[0]);
					continue;
				}
				else if(tokens.length == 2) {
					double bal = Double.parseDouble(tokens[1]);
					a = new BasicAccount(bal);
				}
				else {
					double bal = Double.parseDouble(tokens[1]);
					double intRate = Double.parseDouble(tokens[2]);
					a = new GoldAccount(bal, intRate);
				}
				p.addAccount(a);
			}
			people.add(p);
			input.close();
		}
		catch (IOException e) {
			System.out.println(e);
		}
		return people;
	}
	
	public static List<Person> readPeople3(File file) {
		ArrayList<Person> people = new ArrayList<>();
		ArrayList<String> lines = getLines(file);
		Person p = new Person(lines.remove(0)); 
		while(lines.size()!=0) {
			String[] tokens = lines.remove(0).split("\\s+");
			if(tokens.length == 1) {
				people.add(p);
				p = new Person(tokens[0]);
				continue;
			}
			p.addAccount(buildAccount(tokens));
		}
		people.add(p);
		return people;
	}

	private static Account buildAccount(String[] tokens) {
		Account a;
		if(tokens.length == 2) {  
			double bal = Double.parseDouble(tokens[1]);
			a = new BasicAccount(bal);
		}
		else {  
			double bal = Double.parseDouble(tokens[1]);
			double intRate = Double.parseDouble(tokens[2]);
			a = new GoldAccount(bal, intRate);
		}
		return a;
	}
	
	private static ArrayList<String> getLines(File file) {
		ArrayList<String> lines = new ArrayList<>();
		try {
			Scanner input = new Scanner(file);
			while(input.hasNext()) {
				lines.add(input.nextLine());
			}
			input.close();
		}
		catch (IOException e) {
			System.out.println(e);
		}
		return lines;
	}
	


	
	
	public static void writePeople(File file, List<Person> people ) {
	}
}
 