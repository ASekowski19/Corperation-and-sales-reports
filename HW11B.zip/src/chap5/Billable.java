package chap5;

public interface Billable {
	public String getReceipt();
}
